
const menuBtn=document.querySelector('.menu-btn');const nav=document.querySelector('.nav-links');if(menuBtn){menuBtn.addEventListener('click',()=>nav.classList.toggle('open'));}
const form=document.querySelector('#quoteForm');
function val(id){const el=document.getElementById(id);return el?el.value.trim():''}
function buildMessage(){return `Offerteaanvraag via Roels Vlonder & Terras\n\nNaam: ${val('name')}\nTelefoon: ${val('phone')}\nE-mail: ${val('email')}\nPlaats: ${val('city')}\nProject: ${val('project')}\nOppervlakte: ${val('area')}\nMateriaal: ${val('material')}\n\nOmschrijving:\n${val('message')}`}
function validBasics(){const n=val('name'),p=val('phone'),e=val('email'),m=val('message');if(!n||(!p&&!e)||!m){alert('Vul minimaal uw naam, telefoon of e-mail en een korte omschrijving in.');return false}return true}
const wa=document.querySelector('#sendWhatsApp');if(wa){wa.addEventListener('click',e=>{e.preventDefault();if(!validBasics())return;window.open('https://wa.me/31657082360?text='+encodeURIComponent(buildMessage()),'_blank')})}
const mail=document.querySelector('#sendEmail');if(mail){mail.addEventListener('click',e=>{e.preventDefault();if(!validBasics())return;location.href='mailto:roelandlindhout01@gmail.com?subject='+encodeURIComponent('Offerteaanvraag website')+'&body='+encodeURIComponent(buildMessage())})}
